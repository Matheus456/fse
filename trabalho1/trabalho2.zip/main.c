#include <stdio.h>
#include <time.h>
#include <bcm2835.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>

#include "control_lcd.h"
#include "./modules/i2c/temperature_module_i2c.h"
#include "./modules/uart/module_uart.h"

void register_csv(float *total);
int cfileexists(const char *filename);
void create_marks_csv(char *filename, float *values);
void * printTemperatures(void *args);

void trata_interrupcao(pthread_t tI2c, pthread_t tUart, pthread_t tPrintTemperatures) {
  pthread_cancel(tI2c);
  pthread_cancel(tPrintTemperatures);
  pthread_cancel(tUart);
}


int main(void) {
  pthread_t tI2c, tUart, tPrintTemperatures;
  // signal(SIGINT, trata_interrupcao(tI2c, tUart, tPrintTemperatures));
  struct Temperatures temperatures;
  pthread_create(&tI2c, NULL, temperature_i2c, &temperatures);
  pthread_create(&tUart, NULL, uart_main, &temperatures);
  pthread_create(&tPrintTemperatures, NULL, printTemperatures, &temperatures);

	pthread_join(tI2c, NULL);
	pthread_join(tUart, NULL);
	pthread_join(tPrintTemperatures, NULL);
  return 0;
}

void * printTemperatures(void *args) {
  struct Temperatures *temperatures = args;
  int i=0;
  while(i<10){
    sleep(2);
    printf("TE = %f, TI = %f, TR = %f", temperatures->te, temperatures->ti, temperatures->tr);
    i++;
  }

}

void register_csv(float *total)
{
    printf("Temperatura: %0.2lf\nPressão:   %0.2lf\nUmidade    %0.2lf%%\n", (total[0] / 10), (total[1] / 10), (total[2] / 10));
    create_marks_csv("data.csv", total);
}

int cfileexists(const char *filename)
{
    /* try to open file to read */
    FILE *file;
    if (file = fopen(filename, "r"))
    {
        fclose(file);
        return 1;
    }
    return 0;
}

void create_marks_csv(char *filename, float *values)
{
    FILE *fp;
    int file_exists;
    file_exists = cfileexists(filename);
    fp = fopen(filename, "a");
    if (file_exists != 1)
    {
        fprintf(fp, "Temperatura, Pressão, Umidade, data, hora");
    }
    fprintf(fp, "\n%0.2lf , %0.2lf , %0.2lf%% ", values[0] / 10, values[1] / 10, values[2] / 10);
    time_t t = time(NULL);
    struct tm date = *localtime(&t);
    fprintf(fp, "%d-%02d-%02d , %02d:%02d:%02d", date.tm_mday, date.tm_mon + 1, date.tm_year + 1900, date.tm_hour, date.tm_min, date.tm_sec);

    fclose(fp);
}