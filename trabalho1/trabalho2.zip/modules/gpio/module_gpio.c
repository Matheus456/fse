#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <bcm2835.h>
#include <unistd.h>

#define ON 0
#define OFF 1

/* 
 * Configuração dos pinos dos LEDs e Botão
*/
#define FAN RPI_V2_GPIO_P1_18 // BCM 24
#define RESISTOR RPI_V2_GPIO_P1_16 // BCM 23

void configura_pinos(){
    // Configura pinos dos LEDs como saídas
    bcm2835_gpio_fsel(RESISTOR, BCM2835_GPIO_FSEL_OUTP);
    bcm2835_gpio_fsel(FAN, BCM2835_GPIO_FSEL_OUTP);
}

void start_resistor(int resistor_mask) {
    bcm2835_gpio_write(RESISTOR, resistor_mask & 1 );
}

void start_fan(int fan_mask) {
    bcm2835_gpio_write(FAN, fan_mask & 1 );
}


void trata_interrupcao(int sinal) {
    start_resistor(OFF);
    start_fan(ON);
    bcm2835_close();
    exit(0);
}

int main(int argc, char **argv)
{

    if (!bcm2835_init())
      exit(1);
      
    configura_pinos();

    signal(SIGINT, trata_interrupcao);

    
    int counter;
    printf("Resetando\n");
    start_resistor(OFF);
    start_fan(OFF);
    sleep(2);
    printf("Inicializando Ventoinha\n");
    start_fan(ON);
    sleep(3);
    printf("Inicializando Resistor\n");
    start_resistor(ON);
    sleep(3);
    printf("Desligando Ventoinha\n");
    start_fan(OFF);
    sleep(3);
    printf("Desligando Resistor\n");
    start_resistor(OFF);
}

