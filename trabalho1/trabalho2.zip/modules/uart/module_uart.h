#include "../../main.h"
#define RASP_UART_DEVICE                              "/dev/serial0"

void *uart_main(void *params);
int conexao_uart();
void escrever_dados_uart(unsigned char *, int);
void mensagem_solicitacao(unsigned char *);
void ler_dados_uart(unsigned char *, int, int, struct Temperatures *temperatures);
