#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>  //Usado para a UART
#include <fcntl.h>   //Usado para a UART
#include <termios.h> //Usado para a UART
#include <string.h>
#include "module_uart.h"

#define UART_TEMP 161
#define UART_POT 162


int conexao_uart();
void escrever_dados_uart(unsigned char *, int);
void mensagem_solicitacao(unsigned char *, int);
void ler_dados_uart(unsigned char *, int, int, struct Temperatures *temperatures);

void *uart_main(void *params)
{
    struct Temperatures *temperatures = params;
    int escolha;
    int uart0_filestream = -1;
    uart0_filestream = conexao_uart();
    unsigned char tx_buffer_temp[260];
    unsigned char tx_buffer_pot[260];
 
 
    mensagem_solicitacao(&tx_buffer_temp[0], UART_TEMP);
    mensagem_solicitacao(&tx_buffer_pot[0], UART_POT);

    escrever_dados_uart(&tx_buffer_temp[0], uart0_filestream);
    ler_dados_uart(&tx_buffer_temp[0], uart0_filestream, escolha, temperatures);

    escrever_dados_uart(&tx_buffer_pot[0], uart0_filestream);
    ler_dados_uart(&tx_buffer_pot[0], uart0_filestream, escolha, temperatures);
    sleep(1);
    close(uart0_filestream);
}

int conexao_uart()
{
    int uart0_filestream = -1;
    uart0_filestream = open("/dev/serial0", O_RDWR | O_NOCTTY | O_NDELAY | O_NONBLOCK); //Open in non blocking read/write mode

    if (uart0_filestream == -1)
    {
        printf("Erro - Não foi possível iniciar a UART.\n");
        close(uart0_filestream);
        exit(0);
    }
    else
    {
        printf("UART inicializada!\n");
    }

    struct termios options;
    tcgetattr(uart0_filestream, &options);
    options.c_cflag = B115200 | CS8 | CLOCAL | CREAD; //<Set baud rate
    options.c_iflag = IGNPAR;
    options.c_oflag = 0;
    options.c_lflag = 0;
    tcflush(uart0_filestream, TCIFLUSH);
    tcsetattr(uart0_filestream, TCSANOW, &options);
    return uart0_filestream;
}

void ler_dados_uart(unsigned char *tx_buffer, int uart0_filestream, int codigo, struct Temperatures *temperatures)
{
    while(1) {
        float rx_buffer;
        int rx_length = read(uart0_filestream, &rx_buffer, sizeof(rx_buffer)); //Filestream, buffer to store in, number of bytes to read (max)
        temperatures->ti = rx_buffer;
        sleep(0.5);
    }
}

void escrever_dados_uart(unsigned char *tx_buffer, int uart0_filestream)
{
    printf("Escrevendo caracteres na UART ...\n");
    int count = write(uart0_filestream, tx_buffer, strlen((char *)tx_buffer));
    if (count < 0)
    {
        printf("UART TX error\n");
    }
    else
    {
        printf("escrito.\n");
    }
}

void mensagem_solicitacao(unsigned char *tx_buffer, int code)
{
    unsigned char *p_tx_buffer;
    p_tx_buffer = tx_buffer;
    *p_tx_buffer++ = code;
    *p_tx_buffer++ = 6;
    *p_tx_buffer++ = 7;
    *p_tx_buffer++ = 2;
    *p_tx_buffer++ = 1;
    *p_tx_buffer++ = '\0';
}