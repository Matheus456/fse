#ifndef TEMPERATURE_STRUCT
#define TEMPERATURE_STRUCT
struct Temperatures {
   float te;
   float ti;
   float tr;
   float tHysteresis;
   float tPotentiometer;
};  
#endif
